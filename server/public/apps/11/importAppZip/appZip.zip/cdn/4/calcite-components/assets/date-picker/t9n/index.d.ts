export type DatePickerMessages = {
  nextMonth: string;
  prevMonth: string;
  monthMenu: string;
  yearMenu: string;
  year: string;
};
